package com.example.recycle_country_details;


import android.view.View;

import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public abstract class ExampleAdapter extends RecyclerView.Adapter<ExampleAdapter.ExampleViewHolder> {
    private ArrayList<ExampleItem> ExampleList;
    private MainActivity.RecyclerClickListener listener;

    public ExampleAdapter(ArrayList<ExampleItem> data, MainActivity.RecyclerClickListener listener) {
        this.listener = listener;
        this.ExampleList = data;
    }


    public static class ExampleViewHolder extends RecyclerView.ViewHolder {

        public TextView mTextView1;
        public TextView mTextView2;


        public ExampleViewHolder(@NonNull View itemView) {
            super(itemView);
            mTextView1 = itemView.findViewById(R.id.textView);
            mTextView2 = itemView.findViewById(R.id.textView2);

        }

    }
}

