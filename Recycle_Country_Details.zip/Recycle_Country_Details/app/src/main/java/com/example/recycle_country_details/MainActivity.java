package com.example.recycle_country_details;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().setTitle("Countries");

        ArrayList<ExampleItem> exampleList = new ArrayList<>();
        exampleList.add(new ExampleItem("+977", "Nepal"));
        exampleList.add(new ExampleItem("+657", "India"));
        exampleList.add(new ExampleItem("+217", "Canada"));
        exampleList.add(new ExampleItem("+399", "USA"));
        exampleList.add(new ExampleItem("+213", "Algeria"));
        exampleList.add(new ExampleItem("+54", "Argentina"));
        exampleList.add(new ExampleItem("+166", "Iraq"));
        exampleList.add(new ExampleItem("+098", "Afganistan"));
        exampleList.add(new ExampleItem("+433", "Maldives"));
        exampleList.add(new ExampleItem("+899", "Columbia"));
        exampleList.add(new ExampleItem("+007", "Spain"));
        exampleList.add(new ExampleItem("+178", "Italy"));
        exampleList.add(new ExampleItem("+61", "Australia"));
        exampleList.add(new ExampleItem("+623", "West Indies"));
        exampleList.add(new ExampleItem("+987", "Chile"));
        exampleList.add(new ExampleItem("+667", "Russia"));
        exampleList.add(new ExampleItem("+593", "Equador"));
        exampleList.add(new ExampleItem("+1-340", "England"));
        exampleList.add(new ExampleItem("+971", "UAE"));
        exampleList.add(new ExampleItem("+590", "Germany"));
        exampleList.add(new ExampleItem("+112", "Portugal"));
        exampleList.add(new ExampleItem("+51", "SriLanka"));
        exampleList.add(new ExampleItem("+078", "Iran"));
        exampleList.add(new ExampleItem("+048", "Pakistan"));
        exampleList.add(new ExampleItem("+668", "Bhutan"));
        exampleList.add(new ExampleItem("+124", "France"));
        exampleList.add(new ExampleItem("+407", "Costa Rica"));
        exampleList.add(new ExampleItem("+078", "Korea"));
        exampleList.add(new ExampleItem("+616", "Japan"));
        exampleList.add(new ExampleItem("+723", "China"));
        exampleList.add(new ExampleItem("+907", "Belgium"));
        exampleList.add(new ExampleItem("+227", "Ireland"));



        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ExampleAdapter(exampleList, new RecyclerClickListener() {

            @Override
            public void onClick(ExampleItem exampleItem) {
                Toast.makeText(MainActivity.this, exampleItem.getText1(), Toast.LENGTH_SHORT).show();
                Toast.makeText(MainActivity.this, exampleItem.getText2(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @NonNull
            @org.jetbrains.annotations.NotNull
            @Override
            public ExampleViewHolder onCreateViewHolder(@NonNull @org.jetbrains.annotations.NotNull ViewGroup parent, int viewType) {
                return null;
            }

            @Override
            public void onBindViewHolder(@NonNull @org.jetbrains.annotations.NotNull ExampleAdapter.ExampleViewHolder holder, int position) {

            }

            @Override
            public int getItemCount() {
                return 0;
            }
        };

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

    }

    interface RecyclerClickListener{
        void onClick(ExampleItem exampleItem);
    }
}

